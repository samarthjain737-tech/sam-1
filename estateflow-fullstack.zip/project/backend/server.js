'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const db = require('./db');
const { sign, authMiddleware } = require('./auth');

const PORT = process.env.PORT || 4000;
const PUBLIC = path.join(__dirname, '..', 'public');

// ─── helpers ──────────────────────────────────────────────────────────────────
function readBody(req) {
  return new Promise((res, rej) => {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => { try { res(JSON.parse(data || '{}')); } catch { res({}); } });
    req.on('error', rej);
  });
}

function json(res, code, body) {
  const s = JSON.stringify(body);
  res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type,Authorization', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS' });
  res.end(s);
}

function serveFile(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mime = { '.html':'text/html', '.js':'application/javascript', '.css':'text/css', '.ico':'image/x-icon', '.png':'image/png' }[ext] || 'application/octet-stream';
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    res.writeHead(200, { 'Content-Type': mime });
    res.end(data);
  });
}

// ─── generic CRUD factory ─────────────────────────────────────────────────────
function crudRoutes(table, cols) {
  return {
    list: (req, res, _params, query) => {
      const rows = db.prepare(`SELECT * FROM ${table} ORDER BY id DESC`).all();
      json(res, 200, { data: rows, total: rows.length });
    },
    get: (req, res, params) => {
      const row = db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(params.id);
      if (!row) return json(res, 404, { error: 'Not found' });
      json(res, 200, row);
    },
    create: async (req, res) => {
      const body = await readBody(req);
      const allowed = cols.filter(c => body[c] !== undefined);
      if (!allowed.length) return json(res, 400, { error: 'No valid fields' });
      const stmt = db.prepare(`INSERT INTO ${table} (${allowed.join(',')}) VALUES (${allowed.map(()=>'?').join(',')})`);
      const result = stmt.run(...allowed.map(c => body[c]));
      json(res, 201, { id: result.lastInsertRowid });
    },
    update: async (req, res, params) => {
      const body = await readBody(req);
      const allowed = cols.filter(c => body[c] !== undefined);
      if (!allowed.length) return json(res, 400, { error: 'No valid fields' });
      db.prepare(`UPDATE ${table} SET ${allowed.map(c=>c+'=?').join(',')} WHERE id=?`).run(...allowed.map(c=>body[c]), params.id);
      json(res, 200, { ok: true });
    },
    delete: (req, res, params) => {
      db.prepare(`DELETE FROM ${table} WHERE id=?`).run(params.id);
      json(res, 200, { ok: true });
    },
  };
}

// ─── route definitions ────────────────────────────────────────────────────────
const modules = {
  leads:           crudRoutes('leads',           ['name','phone','email','source','stage','project','assigned_to','notes','created_at']),
  contacts:        crudRoutes('contacts',        ['name','phone','email','company','tag','created_at']),
  'channel-partners': crudRoutes('channel_partners', ['name','contact_person','phone','email','stage','deals_closed']),
  projects:        crudRoutes('projects',        ['name','location','type','status','total_units']),
  'site-visits':   crudRoutes('site_visits',     ['customer_name','project','scheduled_at','status','notes']),
  bookings:        crudRoutes('bookings',        ['customer_name','project','unit','amount','status','date']),
  expenses:        crudRoutes('expenses',        ['category','amount','project','date','notes','approved_by']),
  units:           crudRoutes('units',           ['project','unit_no','type','facing','area','price','status']),
  deals:           crudRoutes('deals',           ['customer_name','project','unit','value','stage','closed_at']),
  payments:        crudRoutes('payments',        ['customer','project','type','amount','method','date','status','due_date']),
  campaigns:       crudRoutes('campaigns',       ['name','channel','budget','leads_generated','status','start_date']),
  'team-members':  crudRoutes('team_members',    ['name','email','phone','role','desig','region','team','dob','initials','color']),
};

// ─── router ───────────────────────────────────────────────────────────────────
async function route(req, res) {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const pathname = url.pathname;
  const method = req.method;

  // CORS preflight
  if (method === 'OPTIONS') { json(res, 204, {}); return; }

  // Static files
  if (!pathname.startsWith('/api/')) {
    let filePath = path.join(PUBLIC, pathname === '/' ? 'index.html' : pathname);
    if (fs.existsSync(filePath) && fs.statSync(filePath).isDirectory()) filePath = path.join(filePath, 'index.html');
    return serveFile(res, filePath);
  }

  // Auth: login endpoint is public
  if (pathname === '/api/login' && method === 'POST') {
    const body = await readBody(req);
    const user = db.prepare(`SELECT * FROM users WHERE username=?`).get(body.username);
    if (!user || user.password !== body.password) return json(res, 401, { error: 'Invalid credentials' });
    const token = sign({ id: user.id, username: user.username, role: user.role });
    return json(res, 200, { token, user: { id: user.id, name: user.name, role: user.role } });
  }

  // All other API routes require auth
  const user = authMiddleware(req);
  if (!user) return json(res, 401, { error: 'Unauthorized' });

  // Overview/dashboard
  if (pathname === '/api/overview' && method === 'GET') {
    const totalLeads = db.prepare(`SELECT COUNT(*) as c FROM leads`).get().c;
    const totalProjects = db.prepare(`SELECT COUNT(*) as c FROM projects`).get().c;
    const totalBookings = db.prepare(`SELECT COUNT(*) as c FROM bookings WHERE status='Confirmed'`).get().c;
    const totalRevenue = db.prepare(`SELECT COALESCE(SUM(amount),0) as s FROM payments WHERE status='Paid'`).get().s;
    const byStage = db.prepare(`SELECT stage, COUNT(*) as count FROM leads GROUP BY stage`).all();
    const recentLeads = db.prepare(`SELECT * FROM leads ORDER BY id DESC LIMIT 10`).all();
    return json(res, 200, { totalLeads, totalProjects, totalBookings, totalRevenue, byStage, recentLeads });
  }

  // Reports
  if (pathname === '/api/reports' && method === 'GET') {
    const leadsBySource = db.prepare(`SELECT source, COUNT(*) as count FROM leads GROUP BY source`).all();
    const leadsByStage = db.prepare(`SELECT stage, COUNT(*) as count FROM leads GROUP BY stage`).all();
    const revenueByProject = db.prepare(`SELECT project, SUM(amount) as total FROM payments WHERE status='Paid' GROUP BY project`).all();
    const expensesByCategory = db.prepare(`SELECT category, SUM(amount) as total FROM expenses GROUP BY category`).all();
    return json(res, 200, { leadsBySource, leadsByStage, revenueByProject, expensesByCategory });
  }

  // Birthdays (team members with upcoming/today birthday)
  if (pathname === '/api/birthdays' && method === 'GET') {
    const members = db.prepare(`SELECT * FROM team_members WHERE dob IS NOT NULL`).all();
    const today = new Date();
    const result = members.map(m => {
      const dob = new Date(m.dob);
      const thisYear = new Date(today.getFullYear(), dob.getMonth(), dob.getDate());
      const diff = Math.ceil((thisYear - today) / 86400000);
      return { ...m, daysUntil: diff >= 0 ? diff : diff + 365 };
    }).sort((a, b) => a.daysUntil - b.daysUntil);
    return json(res, 200, { data: result });
  }

  // Due customers (overdue payments)
  if (pathname === '/api/due-customers' && method === 'GET') {
    const rows = db.prepare(`SELECT * FROM payments WHERE status='Overdue' OR (status='Pending' AND due_date < date('now'))`).all();
    return json(res, 200, { data: rows });
  }

  // Org chart (flat list, client builds tree)
  if (pathname === '/api/org-chart' && method === 'GET') {
    const rows = db.prepare(`SELECT * FROM team_members ORDER BY role, name`).all();
    return json(res, 200, { data: rows });
  }

  // Lead activity sub-resource
  const laMatch = pathname.match(/^\/api\/leads\/(\d+)\/activity$/);
  if (laMatch) {
    const leadId = laMatch[1];
    if (method === 'GET') {
      const rows = db.prepare(`SELECT * FROM lead_activity WHERE lead_id=? ORDER BY id DESC`).all(leadId);
      return json(res, 200, { data: rows });
    }
    if (method === 'POST') {
      const body = await readBody(req);
      db.prepare(`INSERT INTO lead_activity (lead_id,type,note,user) VALUES (?,?,?,?)`).run(leadId, body.type||'Note', body.note||'', user.username);
      return json(res, 201, { ok: true });
    }
  }

  // Generic CRUD routes: /api/:module and /api/:module/:id
  const parts = pathname.replace('/api/', '').split('/');
  const modName = parts[0];
  const id = parts[1];
  const mod = modules[modName];
  if (!mod) return json(res, 404, { error: 'Unknown endpoint' });

  const params = id ? { id } : {};
  if (!id && method === 'GET') return mod.list(req, res, params, url.searchParams);
  if (!id && method === 'POST') return mod.create(req, res, params);
  if (id && method === 'GET') return mod.get(req, res, params);
  if (id && method === 'PUT') return mod.update(req, res, params);
  if (id && method === 'DELETE') return mod.delete(req, res, params);

  json(res, 405, { error: 'Method not allowed' });
}

// ─── start ────────────────────────────────────────────────────────────────────
const server = http.createServer((req, res) => {
  route(req, res).catch(err => {
    console.error(err);
    try { json(res, 500, { error: 'Internal error' }); } catch {}
  });
});

server.listen(PORT, () => console.log(`EstateFlow server running on http://localhost:${PORT}`));
