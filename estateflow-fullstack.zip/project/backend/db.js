'use strict';
const { DatabaseSync } = require('node:sqlite');

const db = new DatabaseSync('/home/claude/project/estateflow.db');

db.exec(`PRAGMA journal_mode=WAL;`);

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  password TEXT NOT NULL,
  role TEXT DEFAULT 'staff'
);

CREATE TABLE IF NOT EXISTS leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  source TEXT DEFAULT 'Walk-in',
  stage TEXT DEFAULT 'New',
  project TEXT,
  assigned_to TEXT,
  notes TEXT,
  created_at TEXT DEFAULT (date('now'))
);

CREATE TABLE IF NOT EXISTS lead_activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER REFERENCES leads(id),
  type TEXT,
  note TEXT,
  user TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS contacts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  company TEXT,
  tag TEXT DEFAULT 'Prospect',
  created_at TEXT DEFAULT (date('now'))
);

CREATE TABLE IF NOT EXISTS channel_partners (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  contact_person TEXT,
  phone TEXT,
  email TEXT,
  stage TEXT DEFAULT 'Active',
  deals_closed INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (date('now'))
);

CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  location TEXT,
  type TEXT DEFAULT 'Residential',
  status TEXT DEFAULT 'Active',
  total_units INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (date('now'))
);

CREATE TABLE IF NOT EXISTS site_visits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT,
  project TEXT,
  scheduled_at TEXT,
  status TEXT DEFAULT 'Scheduled',
  notes TEXT
);

CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT NOT NULL,
  project TEXT,
  unit TEXT,
  amount REAL DEFAULT 0,
  status TEXT DEFAULT 'Pending',
  date TEXT DEFAULT (date('now'))
);

CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT,
  amount REAL DEFAULT 0,
  project TEXT,
  date TEXT DEFAULT (date('now')),
  notes TEXT,
  approved_by TEXT
);

CREATE TABLE IF NOT EXISTS units (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project TEXT,
  unit_no TEXT,
  type TEXT DEFAULT '2 BHK',
  facing TEXT DEFAULT 'North',
  area REAL,
  price REAL,
  status TEXT DEFAULT 'unsold'
);

CREATE TABLE IF NOT EXISTS deals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT,
  project TEXT,
  unit TEXT,
  value REAL DEFAULT 0,
  stage TEXT DEFAULT 'Negotiation',
  closed_at TEXT
);

CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer TEXT,
  project TEXT,
  type TEXT DEFAULT 'Token',
  amount REAL DEFAULT 0,
  method TEXT DEFAULT 'Bank Transfer',
  date TEXT DEFAULT (date('now')),
  status TEXT DEFAULT 'Pending',
  due_date TEXT
);

CREATE TABLE IF NOT EXISTS campaigns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  channel TEXT DEFAULT 'Google Ads',
  budget REAL DEFAULT 0,
  leads_generated INTEGER DEFAULT 0,
  status TEXT DEFAULT 'Active',
  start_date TEXT DEFAULT (date('now'))
);

CREATE TABLE IF NOT EXISTS team_members (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  role TEXT DEFAULT 'Salesmen',
  desig TEXT,
  region TEXT,
  team TEXT,
  dob TEXT,
  initials TEXT,
  color TEXT DEFAULT '#2F5D8A'
);
`);

// Seed only if empty
const userCount = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
if (userCount === 0) {
  db.prepare(`INSERT INTO users (username,name,password,role) VALUES (?,?,?,?)`).run('admin','Admin User','admin123','admin');

  const projects = [
    ['Maha Fibre','Mumbai','Residential','Active',75],
    ['Skyline Residency','Delhi','Residential','Active',60],
    ['Greenfield Towers','Pune','Residential','Active',48],
    ['Sunrise Heights','Bangalore','Commercial','Active',120],
    ['Blue Bay Villas','Goa','Luxury','Upcoming',30],
  ];
  const projStmt = db.prepare(`INSERT INTO projects (name,location,type,status,total_units) VALUES (?,?,?,?,?)`);
  projects.forEach(p => projStmt.run(...p));

  const sources = ['Walk-in','Facebook','Google','Reference','IVR','Campaign','Broker'];
  const stages = ['New','Contacted','Site visit','Negotiation','Booked'];
  const names = ['Rahul Sharma','Priya Patel','Amit Kumar','Sneha Joshi','Ravi Verma','Kavya Nair','Suresh Rao','Divya Singh','Arun Mehta','Pooja Gupta','Vikram Desai','Anjali Shah','Deepak Pillai','Neha Agarwal','Sanjay Tiwari'];
  const leadStmt = db.prepare(`INSERT INTO leads (name,phone,email,source,stage,project,assigned_to,created_at) VALUES (?,?,?,?,?,?,?,?)`);
  for (let i = 0; i < 60; i++) {
    const nm = names[i % names.length] + (i > 14 ? ' ' + i : '');
    const ph = '+91 9' + String(Math.floor(Math.random()*900000000+100000000));
    const em = nm.toLowerCase().replace(/\s/g,'') + '@gmail.com';
    const src = sources[i % sources.length];
    const stg = stages[i % stages.length];
    const proj = projects[i % projects.length][0];
    const days = i * 3;
    const d = new Date(Date.now() - days*86400000);
    leadStmt.run(nm, ph, em, src, stg, proj, 'Admin', d.toISOString().slice(0,10));
  }

  const tms = [
    ['Abhishek Singh','abhishek@estateflow.io','+91 81309 81496','Manager','Sourcing manager','Bangalore','—','1990-03-15','AS','#7A5DA8'],
    ['Admin','admin@estateflow.io','+91 83692 37958','Admin','Director','Mumbai','—','1985-06-22','AD','#3D8361'],
    ['Ajay Chavan','ajaychavan@estateflow.io','+91 82882 55552','Salesmen','Sales','—','Frontend Dev','1993-11-08','AC','#E0A85B'],
    ['Akash Manager','akash@estateflow.io','+91 98070 68088','Manager','Pre sales','Mumbai','—','1988-01-20','AM','#C0573F'],
    ['Tushar S.','tushar@estateflow.io','+91 90001 11001','Manager','Sales manager','Pune','Design Team','1987-07-14','TS','#2F5D8A'],
    ['Hitesh S.','hitesh@estateflow.io','+91 90001 11002','Manager','Sales manager','Mumbai','Frontend Dev','1991-12-03','HS','#7A5DA8'],
    ['Shaniya A.','shaniya@estateflow.io','+91 90001 11003','Manager','Sales manager','Delhi','Sales Delhi','1992-09-25','SA','#C0573F'],
    ['Sarath S.','sarath@estateflow.io','+91 90001 11004','Manager','Sales manager','Mumbai','Sales Mumbai','1989-04-10','SS','#3D8361'],
    ['Vibhav','vibhav@estateflow.io','+91 90001 11005','Manager','Sales manager','Bangalore','Support Bangalore','1986-08-18','V','#7FB6E0'],
    ['Priya Nair','priya@estateflow.io','+91 90001 11006','Salesmen','Sales','Bangalore','Sales Bangalore','1995-02-28','PN','#C0573F'],
    ['Rahul Verma','rahul@estateflow.io','+91 90001 11007','Salesmen','Sales','Delhi','Sales Delhi','1994-10-05','RV','#E0A85B'],
    ['Meera Pillai','meera@estateflow.io','+91 90001 11008','Agent','Pre sales','Mumbai','Sales Mumbai','1996-06-15','MP','#7A5DA8'],
    ['Deepak Nair','deepak@estateflow.io','+91 90001 11009','Salesmen','Sales','Delhi','Sales Delhi','1993-03-22','DN','#9AA5A8'],
    ['Nishant Test','nishant@estateflow.io','+91 90001 11010','Agent','Support','Pune','Support Bangalore','1997-11-11','NT','#7FB6E0'],
    ['Yami Shrivastav','yami@estateflow.io','+91 90001 11011','Salesmen','Sales','Mumbai','Sales Mumbai','1995-05-30','YS','#C0573F'],
  ];
  const tmStmt = db.prepare(`INSERT INTO team_members (name,email,phone,role,desig,region,team,dob,initials,color) VALUES (?,?,?,?,?,?,?,?,?,?)`);
  tms.forEach(t => tmStmt.run(...t));

  const cpStmt = db.prepare(`INSERT INTO channel_partners (name,contact_person,phone,email,stage,deals_closed) VALUES (?,?,?,?,?,?)`);
  [['PropVentures','Rajan Mehta','+91 9800001111','rajan@propventures.com','Active',12],
   ['HomeConnect','Sita Rao','+91 9800002222','sita@homeconnect.com','Active',8],
   ['RealtyHub','Vishal Gupta','+91 9800003333','vishal@realtyhub.com','Inactive',5],
   ['EstateX','Priya Sharma','+91 9800004444','priya@estatex.com','Active',15],
  ].forEach(r => cpStmt.run(...r));

  const bookStmt = db.prepare(`INSERT INTO bookings (customer_name,project,unit,amount,status,date) VALUES (?,?,?,?,?,?)`);
  [['Amit Kumar','Maha Fibre','A-101',4500000,'Confirmed','2025-01-15'],
   ['Sneha Joshi','Skyline Residency','B-204',3200000,'Pending','2025-02-20'],
   ['Ravi Verma','Greenfield Towers','A-302',2800000,'Confirmed','2025-03-05'],
   ['Kavya Nair','Maha Fibre','B-105',5100000,'Cancelled','2025-03-18'],
   ['Suresh Rao','Sunrise Heights','C-401',6200000,'Confirmed','2025-04-10'],
  ].forEach(r => bookStmt.run(...r));

  const payStmt = db.prepare(`INSERT INTO payments (customer,project,type,amount,method,date,status,due_date) VALUES (?,?,?,?,?,?,?,?)`);
  [['Amit Kumar','Maha Fibre','Token',100000,'Cheque','2025-01-15','Paid','2025-01-30'],
   ['Sneha Joshi','Skyline Residency','Installment',500000,'NEFT','2025-02-20','Pending','2025-03-20'],
   ['Ravi Verma','Greenfield Towers','Token',75000,'Cash','2025-03-05','Paid','2025-03-15'],
   ['Suresh Rao','Sunrise Heights','Token',150000,'Bank Transfer','2025-04-10','Paid','2025-04-20'],
   ['Deepak Nair','Maha Fibre','Installment',250000,'NEFT','2025-02-01','Overdue','2025-03-01'],
   ['Meera Pillai','Skyline Residency','Installment',300000,'NEFT','2025-03-10','Overdue','2025-04-10'],
  ].forEach(r => payStmt.run(...r));

  const expStmt = db.prepare(`INSERT INTO expenses (category,amount,project,date,notes,approved_by) VALUES (?,?,?,?,?,?)`);
  [['Marketing',85000,'Maha Fibre','2025-01-10','Google Ads campaign','Admin'],
   ['Site Development',250000,'Greenfield Towers','2025-02-15','Foundation work','Admin'],
   ['Staff',120000,'Skyline Residency','2025-03-01','Sales team salary','Admin'],
   ['Marketing',45000,'Sunrise Heights','2025-03-20','Facebook Ads','Admin'],
  ].forEach(r => expStmt.run(...r));

  const campStmt = db.prepare(`INSERT INTO campaigns (name,channel,budget,leads_generated,status,start_date) VALUES (?,?,?,?,?,?)`);
  [['Summer Sale 2025','Google Ads',150000,42,'Active','2025-04-01'],
   ['FB Leads Q1','Facebook',80000,28,'Completed','2025-01-15'],
   ['Referral Drive','WhatsApp',20000,15,'Active','2025-03-01'],
   ['Instagram Push','Instagram',60000,18,'Paused','2025-02-10'],
  ].forEach(r => campStmt.run(...r));

  const svStmt = db.prepare(`INSERT INTO site_visits (customer_name,project,scheduled_at,status,notes) VALUES (?,?,?,?,?)`);
  [['Rahul Sharma','Maha Fibre','2025-04-20 10:00','Completed','Interested in 2BHK'],
   ['Priya Patel','Skyline Residency','2025-04-22 14:00','Scheduled','First visit'],
   ['Amit Kumar','Greenfield Towers','2025-04-25 11:00','Cancelled','Rescheduled'],
  ].forEach(r => svStmt.run(...r));

  const dealStmt = db.prepare(`INSERT INTO deals (customer_name,project,unit,value,stage,closed_at) VALUES (?,?,?,?,?,?)`);
  [['Amit Kumar','Maha Fibre','A-101',4500000,'Won','2025-01-20'],
   ['Suresh Rao','Sunrise Heights','C-401',6200000,'Won','2025-04-15'],
   ['Neha Agarwal','Skyline Residency','B-301',3800000,'Negotiation',null],
   ['Sanjay Tiwari','Greenfield Towers','A-205',3100000,'Proposal',null],
  ].forEach(r => dealStmt.run(...r));

  const unitStmt = db.prepare(`INSERT INTO units (project,unit_no,type,facing,area,price,status) VALUES (?,?,?,?,?,?,?)`);
  const statuses = ['sold','sold','sold','unsold','hold','rent','unsold','sold'];
  const types = ['1 BHK','2 BHK','3 BHK','4 BHK'];
  const facings = ['North','South','East','West'];
  for (let i = 0; i < 30; i++) {
    unitStmt.run(projects[i%3][0], `A-${101+i}`, types[i%4], facings[i%4], 600+i*20, 2500000+i*100000, statuses[i%8]);
  }

  console.log('Database seeded.');
}

module.exports = db;
