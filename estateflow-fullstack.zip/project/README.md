# EstateFlow CRM — Full Stack

A real-estate CRM with a **zero-dependency Node.js backend** (no `npm install` needed) and an enhanced frontend behind a login screen.

## Requirements

- **Node.js 22+** (uses built-in `node:sqlite` and `node:crypto`)
- That's it — no npm packages required.

## Running

```bash
node backend/server.js
```

Then open **http://localhost:4000** in your browser.

## Login

| Username | Password  | Role  |
|----------|-----------|-------|
| admin    | admin123  | Admin |
| agent1   | agent123  | Agent |

## What's live (real DB, persists across restarts)

| Module         | Status         |
|----------------|----------------|
| Overview KPIs  | ✅ Live API    |
| Leads          | ✅ Live API    |
| Team Members   | ✅ Live CRUD   |
| Birthdays      | ✅ Live API    |
| Due Customers  | ✅ Live API    |
| Contacts       | ✅ API ready   |
| Channel Partners | ✅ API ready |
| Projects       | ✅ API ready   |
| Site Visits    | ✅ API ready   |
| Bookings       | ✅ API ready   |
| Expenses       | ✅ API ready   |
| Units          | ✅ API ready   |
| Deals          | ✅ API ready   |
| Payments       | ✅ API ready   |
| Campaigns      | ✅ API ready   |
| Reports        | ✅ API ready   |

"API ready" = backend routes + SQLite tables exist with seed data; frontend still uses original demo rendering (follows the same wiring pattern as Leads/Team Members to connect).

## API Endpoints

```
POST /api/auth/login       — { username, password } → { token, user }

GET/POST  /api/leads
GET/PUT/DELETE /api/leads/:id
GET/POST  /api/contacts
GET/PUT/DELETE /api/contacts/:id
GET/POST  /api/channel-partners
GET/PUT/DELETE /api/channel-partners/:id
GET/POST  /api/projects
GET/PUT/DELETE /api/projects/:id
GET/POST  /api/site-visits
GET/PUT/DELETE /api/site-visits/:id
GET/POST  /api/bookings
GET/PUT/DELETE /api/bookings/:id
GET/POST  /api/expenses
GET/PUT/DELETE /api/expenses/:id
GET/POST  /api/units
GET/PUT/DELETE /api/units/:id
GET/POST  /api/deals
GET/PUT/DELETE /api/deals/:id
GET/POST  /api/payments
GET/PUT/DELETE /api/payments/:id
GET/POST  /api/campaigns
GET/PUT/DELETE /api/campaigns/:id
GET/POST  /api/team-members
GET/PUT/DELETE /api/team-members/:id

GET /api/overview          — dashboard KPIs
GET /api/reports/summary   — revenue + lead funnel
GET /api/birthdays         — upcoming team birthdays
GET /api/due-customers     — overdue payments
GET /api/org-chart         — team hierarchy tree
```

All endpoints except `/api/auth/login` require `Authorization: Bearer <token>` header.

## Wiring more modules to the frontend

Follow the same pattern used for Leads in `public/index.html`:

```js
async function loadXxxFromApi() {
  const data = await apiFetch('/api/xxx');
  ALL_XXX = data.map(r => ({
    // map API field names to what the render function expects
    id: r.id,
    name: r.name,
    ...
  }));
  renderXxxTable();
}
```

Call `loadXxxFromApi()` inside `bootstrapApp()`.

## File structure

```
project/
  backend/
    server.js    — HTTP server, routing, auth middleware
    db.js        — SQLite schema + seed data
    auth.js      — token sign/verify (built-in crypto, no jwt lib)
  public/
    index.html   — EstateFlow UI with login screen + API wiring
  README.md
```
